const productElement = document.querySelector(".products");

function updateNavbarStyles() {
  let navbar = document.querySelector(".container-lg");
  let button = document.querySelector("button");
  let navLinks1 = document.querySelector("#link1");
  let navLinks2 = document.querySelector("#link2");
  let navLinks3 = document.querySelector("#link3");
  let textSearch = document.querySelector("#text-search");

  if (navbar) {
    if (window.innerWidth < 768) {
      navbar.style.backgroundColor = "blue";
      button.style.backgroundColor = "white";
      navLinks1.style.color = "white";
      navLinks2.style.color = "white";
      navLinks3.style.color = "white";
      textSearch.setAttribute("placeholder", "Tìm kiếm sản phẩm");
    } else {
      navbar.style.backgroundColor = "";
      button.style.backgroundColor = "";
      navLinks1.style.color = "";
      navLinks2.style.color = "";
      navLinks3.style.color = "blue";
    }
  }
}

document.addEventListener("DOMContentLoaded", () => {
  updateNavbarStyles();

  const loginButton = document.querySelector("#login-button");
  if (loginButton) {
    loginButton.addEventListener("click", login);
  }
});

window.addEventListener("resize", updateNavbarStyles);

function login() {
  getUser(handleLogin);
}

async function getData() {
  const url = "http://localhost:3000/accoutUser";
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Response status: ${response.status}`);
    }
    const json = await response.json();
    console.log(json);
  } catch (error) {
    console.error(error.message);
  }
}

function handleLogin(data) {
  let userName = document.querySelector("#userName").value;
  let passWord = document.querySelector("#password").value;

  const user = data.find(
    (user) => user.userName === userName && user.passWord === passWord
  );

  if (user) {
    alert("Đăng Nhập Thành Công");
    window.location.href = "/Trang_Chu/index.html";
  } else {
    alert("Sai Thông Tin hoặc Mật Khẩu");
  }
}
