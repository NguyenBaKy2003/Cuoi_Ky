// DOM
const productElement = document.querySelector(".products");

function updateNavbarStyles() {
  let navbar = document.querySelector(".container-lg");
  let button = document.querySelector("button");
  let navLinks1 = document.querySelector("#link1");
  let navLinks2 = document.querySelector("#link2");
  let navLinks3 = document.querySelector("#link3");
  let textSearch = document.querySelector("#text-search");

  if (navbar) {
    if (window.innerWidth < 768) {
      navbar.style.backgroundColor = "blue";
      button.style.backgroundColor = "white";
      navLinks1.style.color = "white";
      navLinks2.style.color = "white";
      navLinks3.style.color = "white";
      textSearch.setAttribute("placeholder", "Tìm kiếm sản phẩm");
    } else {
      navbar.style.backgroundColor = "";
      button.style.color = "";
      navLinks1.style.color = "";
      navLinks2.style.color = "";
      navLinks3.style.color = "blue";
    }
  }
}
document.addEventListener("DOMContentLoaded", updateNavbarStyles);
window.addEventListener("resize", updateNavbarStyles);

async function getData() {
  let content = "";
  const url = "https://h5ltj4-8080.csb.app/books";
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Response status: ${response.status}`);
    }

    const json = await response.json();
    json.forEach(function (item) {
      content += `<div class="col-md-3">
      <div class="card p-3 bg-body border-0">
        <img
src="${item.images[0].base_url}"
        alt=""
        />
        <div class="container-fluid px-0 py-3">
          <a href=""
            ><img
      src="${item.images[0].base_url}"
            alt=""
              style="
                width: 42px;
                height: 42px;
                top: 6px;
                left: 6px;
                gap: 0px;
                opacity: 0px;
              "
          /></a>
          <a href=""
            ><img
      src="${item.images[0].base_url}"
              alt=""
              style="
                width: 42px;
                height: 42px;
                top: 6px;
                left: 6px;
                gap: 0px;
                opacity: 0px;
              "
          /></a>
          <a href=""
            ><img
      src="${item.images[0].base_url}"

              alt=""
              style="
                width: 42px;
                height: 42px;
                top: 6px;
                left: 6px;
                gap: 0px;
                opacity: 0px;
              "
          /></a>
          <a href=""
            ><img
      src="${item.images[0].base_url}"

              alt=""
              style="
                width: 42px;
                height: 42px;
                top: 6px;
                left: 6px;
                gap: 0px;
                opacity: 0px;
              "
          /></a>
          <a href=""
            ><img
      src="${item.images[0].base_url}"

              alt=""
              style="
                width: 42px;
                height: 42px;
                top: 6px;
                left: 6px;
                gap: 0px;
                opacity: 0px;
              "
          /></a>
        </div>
        <div class="card-body d-none d-lg-block p-0">
          <h4 class="fs-6">Đặc điểm nổi bật</h4>
          <p class="fs-6">
            <i class="fa-solid fa-check" style="color: #74c0fc"></i>
            Kích thước lớn và bìa cứng, tạo cảm giác sang trọng và bền bỉ.
          </p>
          <p class="fs-6">
            <i class="fa-solid fa-check" style="color: #74c0fc"></i>
            Hình vẽ ngộ nghĩnh và màu sắc sống động, thu hút sự chú ý của
            trẻ em.
          </p>
          <p class="fs-6">
            <i class="fa-solid fa-check" style="color: #74c0fc"></i>
            Cung cấp thông tin tổng quát về diện tích, dân số và ngôn ngữ
            của các quốc gia.
          </p>
        </div>
        <div class="card-footer d-none d-lg-block bg-body px-0">
          <p class="fs-6 w-100">
            <i
              class="fa-regular fa-face-grin-hearts"
              style="color: #74c0fc"
            ></i>
            Xem thêm Tóm tắt nội dung sách
            <span
              ><i
                class="fa-solid justify-content-between fa-chevron-right"
              ></i
            ></span>
          </p>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card bg-body">
        <div class="row px-3">
          <div class="container-fluid order-0 p-3">
            <p class="fs-6">
              <span
                class="bg-body-tertiary text-primary text-uppercase rounded-pill"
                ><i class="fa-solid fa-check" style="color: #74c0fc"> </i
                ><strong>Chinh Hang</strong></span
              >
              Tác giả:
              <a href="">
                     ${item.authors ? item.authors[0].name : ""}
                            </a>
                            <p class="fs-6">
                              <span class="card-text py-0 px-0 fs-6 text-warning">
                                ${createStars(item.rating_average)}
                              </span>
                              <span> ${
                                item.quantity_sold
                                  ? `${item.quantity_sold.text} `
                                  : ""
                              }</span>
                            </p>
            <p class="">
             <strong class="fs-4 fw-medium priceProduct">
                                ${item.list_price.toLocaleString(
                                  "vi-VN"
                                )}<sup>₫</sup>
                              </strong></strong>
              <span class="bg-secondary-subtle p-0 rounded-pill"
                >-26%</span
              >
            </p>
            <h5 class="fs-5 p-0">
            ${item.name}
            </h5>
          </div>
          <div class="container-fluid order-2 p-3">
            <h4 class="fs-6">Thông tin chi tiết</h4>
            <div class="">
              <p
                class="d-flex border-bottom pb-2 justify-content-between"
              >
                <span class="w-50">Phiên bản sách</span
                ><span class="w-50">${item.categories.name}</span>
              </p>
              <p
                class="d-flex border-bottom pb-2 justify-content-between"
              >
                <span class="w-50">Công ty phát hành</span
                ><span class="w-50">${
                  item.specifications[0].attributes[0].value
                }</span>
              </p>
              <p
                class="d-flex border-bottom pb-2 justify-content-between"
              >
                <span class="w-50">Ngày xuất bản</span>
                <span class="w-50">
                  ${getPublicationDate(item.specifications[0].attributes)}
                </span>

              </p>
              <p
                class="d-flex border-bottom pb-2 justify-content-between"
              >
                <span class="w-50">Kích thước</span
                >
                <span class="w-50">${stripPTags(
                  getDimensions(item.specifications[0].attributes)
                )}</span>
              </p>
              <p
                class="d-flex border-bottom pb-2 justify-content-between"
              >
                <span class="w-50">Dịch Giả</span
                ><span class="w-50">${getTranslator(
                  item.specifications[0].attributes
                )}</span>
              </p>
              <p
                class="d-flex border-bottom pb-2 justify-content-between"
              >
                <span class="w-50">Loại bìa</span
                ><span class="w-50">${getNguyenLieu(
                  item.specifications[0].attributes
                )}</span>
              </p>
              <p
                class="d-flex border-bottom pb-2 justify-content-between"
              >
                <span class="w-50">Số trang</span
                ><span class="w-50">${getSotrang(
                  item.specifications[0].attributes
                )}</span>
              </p>
              <p class="d-flex justify-content-between">
                <span class="w-50">Nhà xuất bản</span
                ><span class="w-50">${getNhaxuatban(
                  item.specifications[0].attributes
                )}</span>
              </p>
            </div>
          </div>
          <div class="d-block order-1 d-md-none p-3">
            <div class="w-100 bg-body rounded-2">
              <h4 class="fs-6">Số Lượng</h4>
              <div class="d-flex gap-2">
                <button
                  class="btn btn-outline-secondary"
                  type="button"
                  id="button-minus"
                >
                  -
                </button>
                <button
                  type="number"
                  class="form-control text-center"
                  id="quantity"
                  value="1"
                  min="1"
                  style="max-width: 60px"
                >
                  1
                </button>
                <button
                  class="btn btn-outline-secondary"
                  type="button"
                  id="button-plus"
                >
                  +
                </button>
              </div>
              <div class="row my-3">
                <div class="col-12 mb-2">
                  <button class="btn btn-danger w-100">Mua ngay</button>
                </div>
                <div class="col-12 mb-2">
                  <button class="btn btn-outline-primary w-100">
                    Thêm vào giỏ
                  </button>
                </div>
                <div class="col-12">
                  <button class="btn btn-outline-primary w-100">
                    Mua trước trả sau
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="container-md bg-body my-3 p-3 rounded-1">
        <h4 class="ps-6">Mô tả sản phẩm</h4>
        <img
      src="${item.images[0].base_url}"

          alt=""
          class="w-100 py-4"
        />
        <p class=""fs-6>
        ${item.description}</p>
      </div>
    </div>
      <div class="col-md-3 d-none d-md-block">
            <div class="container-fluid bg-body rounded-2 p-3">
              <h4 class="fs-6">Số Lượng</h4>
              <div class="d-flex gap-2">
                <button
                  class="btn btn-outline-secondary"
                  type="button"
                  id="button-minus"
                >
                  -
                </button>
                <button  type="button"
                  class="form-control text-center"
                  id="quantity"
                  value="1"
                  min="1"
                  style="max-width: 60px">
                 
                </button>
                <button
                  class="btn btn-outline-secondary"
                  type="button"
                  id="button-plus"
                >
                  +
                </button>
              </div>
              <div class="row my-3">
                <div class="col-12 mb-2">
                  <button class="btn btn-danger w-100">Mua ngay</button>
                </div>
                <div class="col-12 mb-2">
                  <button class="btn btn-outline-primary w-100">
                    Thêm vào giỏ
                  </button>
                </div>
                <div class="col-12">
                  <button class="btn btn-outline-primary w-100">
                    Mua trước trả sau
                  </button>
                </div>
              </div>
            </div>
          </div>`;
    });
    productElement.innerHTML = content;
  } catch (error) {
    console.error(error.message);
  }
}

getData();

function createStars(rating) {
  let stars = "";
  for (let i = 0; i < 5; i++) {
    if (i < rating) {
      stars += `<i class="fa-solid fa-star fa-xs text-warning"></i>`;
    } else {
      stars += `<i class="fa-solid fa-star fa-xs d-none"></i>`;
    }
  }
  return stars;
}

// Thay the du kien

function getPublicationDate(attributes) {
  const publicationDateAttr = attributes.find(
    (attr) => attr.code === "publication_date"
  );
  return publicationDateAttr ? publicationDateAttr.value : "";
}

function getDimensions(attributes) {
  const dimensionsAttr = attributes.find((attr) => attr.code === "dimensions");
  return dimensionsAttr ? dimensionsAttr.value : "";
}

function stripPTags(attributeValue) {
  return attributeValue.replace(/<\/?p>/g, "");
}

function getTranslator(attributes) {
  const translatorAttr = attributes.find((attr) => attr.code === "dich_gia");
  return translatorAttr ? translatorAttr.value : "";
}

function getNguyenLieu(attributes) {
  const nguyenLieuAttr = attributes.find((attr) => attr.code === "book_cover");
  return nguyenLieuAttr ? nguyenLieuAttr.value : "";
}

function getSotrang(attributes) {
  const sotrangAtt = attributes.find((attr) => attr.code === "number_of_page");
  return sotrangAtt ? sotrangAtt.value : "";
}

function getNhaxuatban(attributes) {
  const nhaXuatbanAttr = attributes.find(
    (attr) => attr.code === "manufacturer"
  );
  return nhaXuatbanAttr ? nhaXuatbanAttr.value : "";
}
