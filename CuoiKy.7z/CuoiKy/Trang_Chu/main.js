const productElement = document.querySelector(".products");
const textSearch = document.querySelector("#text-search");

function updateNavbarStyles() {
  const navbar = document.querySelector(".container-lg");
  const button = document.querySelector("button");
  const navLinks1 = document.querySelector("#link1");
  const navLinks2 = document.querySelector("#link2");
  const navLinks3 = document.querySelector("#link3");

  if (navbar) {
    if (window.innerWidth < 768) {
      navbar.style.backgroundColor = "blue";
      button.style.backgroundColor = "white";
      navLinks1.style.color = "white";
      navLinks2.style.color = "white";
      navLinks3.style.color = "white";
      textSearch.setAttribute("placeholder", "Tìm kiếm sản phẩm");
    } else {
      navbar.style.backgroundColor = "";
      button.style.backgroundColor = "";
      navLinks1.style.color = "";
      navLinks2.style.color = "";
      navLinks3.style.color = "blue";
      textSearch.setAttribute("placeholder", "Free ship đến 30km");
    }
  }
}

document.addEventListener("DOMContentLoaded", updateNavbarStyles);
window.addEventListener("resize", updateNavbarStyles);
document.addEventListener("DOMContentLoaded", () => {
  getData();
  if (textSearch) {
    textSearch.addEventListener("input", function () {
      const searchQuery = textSearch.value;
      getData(searchQuery);
    });
  }
});
async function getData(searchQuery = "", categoryName = "") {
  let content = "";
  const url = "https://h5ltj4-8080.csb.app/books";
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Response status: ${response.status}`);
    }

    const json = await response.json();

    const filteredProducts = json.filter((item) => {
      const matchSearch = item.name
        .toLowerCase()
        .includes(searchQuery.toLowerCase());
      const matchCategory = categoryName
        ? item.categories?.name === categoryName
        : true;
      return matchSearch && matchCategory;
    });

    filteredProducts.forEach((item) => {
      content += `<div class="col product-item" >
                  <a href="/San_Pham/index.html" class="product text-decoration-none">
                    <div class="card h-100 w-100">
                      <img src="${
                        item.images[0]?.large_url
                      }" class="card-img-top" alt="..." style="max-height:150px; font-size:15px" />
                      <div class="card-body justify-content-center">
                        <div class="h-50">
                          <h5 class="card-title mb-0 fs-6" style="max-height: 4.6em; overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical;">
                            ${item.name}
                          </h5>
                          <p class="fs-6">
                            <span class="card-text py-0 px-0 fs-6 text-warning">
                              ${createStars(item.rating_average)}
                            </span>
                            <span> ${
                              item.quantity_sold
                                ? `${item.quantity_sold.text} `
                                : ""
                            }</span>
                          </p>
                        </div>
                        <p class="h-25 d-inline-block"> 
                          <strong class="fs-4 fw-medium priceProduct">
                            ${item.list_price.toLocaleString(
                              "vi-VN"
                            )}<sup>₫</sup>
                          </strong>
                          <span class="bg-secondary-subtle p-0 rounded-pill discountProduct">
                            -26%
                          </span>
                        </p>
                      </div>
                      <div class="card-footer text-center timeShip">
                        Giao siêu tốc 2h
                      </div>
                    </div>
                  </a>
                </div>`;
    });

    // Gắn sản phẩm vào giao diện
    productElement.innerHTML = content;

    // Thêm sự kiện click vào các sản phẩm
    document.querySelectorAll(".product-item").forEach((product) => {
      product.addEventListener("click", () => {
        const productId = product.getAttribute("data-product-id");
        window.location.href = `/San_Pham/index.html?id=${productId}`;
      });
    });
  } catch (error) {
    console.error(error.message);
  }
}

// Lắng nghe sự kiện click cho nút Sách tiếng Việt
let vietNameseBook = document.querySelector("#vietNamese-book");

vietNameseBook.addEventListener("click", function () {
  // Lọc sản phẩm với categories.name là "Sách tiếng Việt"
  getData("", "Sách tiếng Việt");
});

function createStars(rating) {
  let stars = "";
  for (let i = 0; i < 5; i++) {
    stars += `<i class="fa-solid fa-star fa-xs ${
      i < rating ? "text-warning" : "d-none"
    }"></i>`;
  }
  return stars;
}
