// DOM
const productElement = document.querySelector(".products");

function updateNavbarStyles() {
  let navbar = document.querySelector(".container-lg");
  let button = document.querySelector("button");
  let navLinks1 = document.querySelector("#link1");
  let navLinks2 = document.querySelector("#link2");
  let navLinks3 = document.querySelector("#link3");
  let textSearch = document.querySelector("#text-search");

  if (navbar) {
    if (window.innerWidth < 768) {
      navbar.style.backgroundColor = "blue";
      button.style.backgroundColor = "white";
      navLinks1.style.color = "white";
      navLinks2.style.color = "white";
      navLinks3.style.color = "white";
      textSearch.setAttribute("placeholder", "Tìm kiếm sản phẩm");
    } else {
      navbar.style.backgroundColor = "";
      button.style.color = "";
      navLinks1.style.color = "";
      navLinks2.style.color = "";
      navLinks3.style.color = "blue";
    }
  }
}
document.addEventListener("DOMContentLoaded", updateNavbarStyles);
window.addEventListener("resize", updateNavbarStyles);
